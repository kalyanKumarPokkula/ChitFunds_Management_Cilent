-- MySQL dump 10.13  Distrib 8.0.41, for Linux (aarch64)
--
-- Host: localhost    Database: chitfunds
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('0eb72bc29ab8');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chit_groups`
--

DROP TABLE IF EXISTS `chit_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chit_groups` (
  `chit_group_id` varchar(36) NOT NULL,
  `chit_name` varchar(255) NOT NULL,
  `chit_amount` float NOT NULL,
  `duration_months` int NOT NULL,
  `total_members` int NOT NULL,
  `monthly_installment` float NOT NULL,
  `status` varchar(20) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`chit_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chit_groups`
--

LOCK TABLES `chit_groups` WRITE;
/*!40000 ALTER TABLE `chit_groups` DISABLE KEYS */;
INSERT INTO `chit_groups` VALUES ('31694d370df7','Annual Chit - 50000',50000,10,10,5000,'active','2025-05-01','2026-03-01','2025-05-12 08:43:29',NULL),('84c332bc7e0b','Annual Chit - 500000',500000,10,10,50000,'active','2025-05-01','2026-03-01','2025-05-12 09:13:15','2025-05-12 09:13:15'),('9b9bcc5fbd9d','Diamand Saver Plan',100000,10,10,10000,'active','2025-05-01','2026-03-01','2025-05-08 11:30:26',NULL),('b6d3c2655e5c','Silver Saver Plan',25000,10,10,2500,'active','2025-05-01','2026-03-01','2025-05-08 11:32:21',NULL),('fffa04d48f2a','Gold Saver Plan',50000,10,10,5000,'active','2025-05-01','2026-03-01','2025-05-03 13:38:21',NULL);
/*!40000 ALTER TABLE `chit_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chit_members`
--

DROP TABLE IF EXISTS `chit_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chit_members` (
  `chit_member_id` varchar(36) NOT NULL,
  `chit_group_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`chit_member_id`),
  KEY `chit_group_id` (`chit_group_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `chit_members_ibfk_1` FOREIGN KEY (`chit_group_id`) REFERENCES `chit_groups` (`chit_group_id`),
  CONSTRAINT `chit_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chit_members`
--

LOCK TABLES `chit_members` WRITE;
/*!40000 ALTER TABLE `chit_members` DISABLE KEYS */;
INSERT INTO `chit_members` VALUES ('06e64084f5e8','9b9bcc5fbd9d','203e4d7dbace','2025-05-08 11:30:50',NULL),('0c72cabb12ec','fffa04d48f2a','bbc84395d5e2','2025-05-03 13:40:11',NULL),('380d85ab0b42','31694d370df7','203e4d7dbace','2025-05-12 08:43:45',NULL),('44ffd430d574','fffa04d48f2a','203e4d7dbace','2025-05-03 13:40:11',NULL),('4e65b2f84984','31694d370df7','bbc84395d5e2','2025-05-12 08:43:45',NULL),('537fa5ae392d','9b9bcc5fbd9d','8e3e52738d50','2025-05-08 11:30:50',NULL),('718fc959a8ae','fffa04d48f2a','8e3e52738d50','2025-05-03 13:40:11',NULL),('7ee8e77a68b4','31694d370df7','07a7d3b929e0','2025-05-12 08:43:45',NULL),('8dad4ca0b873','84c332bc7e0b','07a7d3b929e0','2025-05-12 09:15:13','2025-05-12 09:15:13'),('8ebf0e3a3f6e','9b9bcc5fbd9d','bbc84395d5e2','2025-05-08 11:30:50',NULL),('94b87d8a5575','b6d3c2655e5c','07a7d3b929e0','2025-05-08 11:32:37',NULL),('990c5169a45d','84c332bc7e0b','8ab099c04852','2025-05-12 09:15:13','2025-05-12 09:15:13'),('a53ee43d34f5','b6d3c2655e5c','8ab099c04852','2025-05-08 11:32:37',NULL),('b01341a14700','84c332bc7e0b','203e4d7dbace','2025-05-12 09:15:13','2025-05-12 09:15:13'),('b3aa05b1f664','9b9bcc5fbd9d','07a7d3b929e0','2025-05-08 11:30:50',NULL),('c04c8268668a','31694d370df7','8e3e52738d50','2025-05-12 08:43:45',NULL),('c6fa77813ee6','84c332bc7e0b','8e3e52738d50','2025-05-12 09:15:13','2025-05-12 09:15:13'),('ca327b1351b7','84c332bc7e0b','bbc84395d5e2','2025-05-12 09:15:13','2025-05-12 09:15:13'),('cf2a41cc7c1e','31694d370df7','8ab099c04852','2025-05-12 08:43:45',NULL),('d4b0cecf4d29','9b9bcc5fbd9d','8ab099c04852','2025-05-08 11:30:50',NULL),('d62c7d6ee18b','fffa04d48f2a','8ab099c04852','2025-05-03 13:40:11',NULL),('ddf09043edb6','fffa04d48f2a','07a7d3b929e0','2025-05-03 13:40:11',NULL),('e10cc6b631f4','b6d3c2655e5c','bbc84395d5e2','2025-05-08 11:32:37',NULL),('f64aa40d275d','b6d3c2655e5c','203e4d7dbace','2025-05-08 11:32:37',NULL),('fab2adcc473f','b6d3c2655e5c','8e3e52738d50','2025-05-08 11:32:37',NULL);
/*!40000 ALTER TABLE `chit_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `installments`
--

DROP TABLE IF EXISTS `installments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `installments` (
  `installment_id` varchar(36) NOT NULL,
  `chit_member_id` varchar(36) NOT NULL,
  `month_number` int NOT NULL,
  `due_date` date NOT NULL,
  `total_amount` float NOT NULL,
  `paid_amount` float NOT NULL,
  `status` enum('PAID','UNPAID','PARTIAL') NOT NULL,
  `payment_date` date DEFAULT NULL,
  `note` text,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`installment_id`),
  KEY `chit_member_id` (`chit_member_id`),
  CONSTRAINT `installments_ibfk_1` FOREIGN KEY (`chit_member_id`) REFERENCES `chit_members` (`chit_member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `installments`
--

LOCK TABLES `installments` WRITE;
/*!40000 ALTER TABLE `installments` DISABLE KEYS */;
INSERT INTO `installments` VALUES ('012b62287e7c4939','d4b0cecf4d29',1,'2025-05-25',10000,10000,'PAID',NULL,NULL,NULL,NULL),('0c5bac59cb91429d','537fa5ae392d',1,'2025-05-25',10000,10000,'PAID',NULL,NULL,NULL,NULL),('3140015a826e45a8','ddf09043edb6',1,'2025-05-25',4200,3000,'UNPAID',NULL,NULL,NULL,NULL),('3615b82f4be64b9c','7ee8e77a68b4',1,'2025-05-25',5000,5000,'PAID',NULL,NULL,NULL,NULL),('3977659e97044848','b01341a14700',1,'2025-05-25',50000,0,'UNPAID',NULL,NULL,NULL,NULL),('3c5ff2c39d9d4d54','8dad4ca0b873',1,'2025-05-25',50000,20000,'PARTIAL','2025-05-13',NULL,NULL,NULL),('41ce0a085e4d44b5','44ffd430d574',1,'2025-05-25',4200,4200,'PAID',NULL,NULL,NULL,NULL),('44003460390d4475','94b87d8a5575',1,'2025-05-25',2500,2500,'PAID',NULL,NULL,NULL,NULL),('55151613e04b406c','4e65b2f84984',1,'2025-05-25',5000,5000,'PAID','2025-05-15',NULL,NULL,NULL),('62e7a76357d442c0','06e64084f5e8',1,'2025-05-25',10000,0,'UNPAID',NULL,NULL,NULL,NULL),('685ffe79875f4f30','8ebf0e3a3f6e',1,'2025-05-25',10000,10000,'PAID',NULL,NULL,NULL,NULL),('69e9586f367d429a','d62c7d6ee18b',1,'2025-05-25',4200,0,'UNPAID',NULL,NULL,NULL,NULL),('7473eea54bb9426e','c6fa77813ee6',1,'2025-05-25',50000,0,'UNPAID',NULL,NULL,NULL,NULL),('75791cba9fc9464a','cf2a41cc7c1e',1,'2025-05-25',5000,5000,'PAID','2025-05-15',NULL,NULL,NULL),('78d41be398ea4da1','990c5169a45d',1,'2025-05-25',50000,0,'UNPAID',NULL,NULL,NULL,NULL),('7dd3db98e10a4fa7','0c72cabb12ec',1,'2025-05-25',4200,0,'UNPAID',NULL,NULL,NULL,NULL),('b709940df82d43c5','fab2adcc473f',1,'2025-05-25',2500,0,'UNPAID',NULL,NULL,NULL,NULL),('bb28df2cc1824df5','a53ee43d34f5',1,'2025-05-25',2500,0,'UNPAID',NULL,NULL,NULL,NULL),('bf291ba6da4544cb','e10cc6b631f4',1,'2025-05-25',2500,0,'UNPAID',NULL,NULL,NULL,NULL),('c9d7b6fa2d1c469f','718fc959a8ae',1,'2025-05-25',4200,0,'UNPAID',NULL,NULL,NULL,NULL),('cd9863bd05864c8e','b3aa05b1f664',1,'2025-05-25',10000,10000,'PAID',NULL,NULL,NULL,NULL),('d025d69010f94a3f','ca327b1351b7',1,'2025-05-25',50000,0,'UNPAID',NULL,NULL,NULL,NULL),('eb9e8d55f6724cc0','380d85ab0b42',1,'2025-05-25',5000,5000,'PAID','2025-05-15',NULL,NULL,NULL),('f2652d83018843c4','f64aa40d275d',1,'2025-05-25',2500,0,'UNPAID',NULL,NULL,NULL,NULL),('fed4920d2ad448d5','c04c8268668a',1,'2025-05-25',5000,5000,'PAID','2025-05-15',NULL,NULL,NULL);
/*!40000 ALTER TABLE `installments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monthly_projections`
--

DROP TABLE IF EXISTS `monthly_projections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_projections` (
  `monthly_projections_id` varchar(36) NOT NULL,
  `chit_group_id` varchar(36) NOT NULL,
  `month_number` int NOT NULL,
  `monthly_subcription` float NOT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `total_payout` float NOT NULL,
  `lifted_date` date DEFAULT NULL,
  `note` text,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`monthly_projections_id`),
  KEY `chit_group_id` (`chit_group_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `monthly_projections_ibfk_1` FOREIGN KEY (`chit_group_id`) REFERENCES `chit_groups` (`chit_group_id`),
  CONSTRAINT `monthly_projections_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monthly_projections`
--

LOCK TABLES `monthly_projections` WRITE;
/*!40000 ALTER TABLE `monthly_projections` DISABLE KEYS */;
INSERT INTO `monthly_projections` VALUES ('0297718707284446','84c332bc7e0b',8,50000,NULL,500000,NULL,NULL,'2025-05-12 09:14:12','2025-05-12 09:14:12'),('03c61e1d4a4241fe','fffa04d48f2a',10,5000,NULL,47000,NULL,NULL,'2025-05-03 13:39:52',NULL),('09858148a2214778','31694d370df7',2,5000,NULL,50000,NULL,NULL,'2025-05-12 08:43:36',NULL),('126f29998f6f4693','9b9bcc5fbd9d',10,10000,NULL,100000,NULL,NULL,'2025-05-08 11:30:34',NULL),('1a83653b766248c9','fffa04d48f2a',9,4900,NULL,46000,NULL,NULL,'2025-05-03 13:39:52',NULL),('1fa8bcb660064694','9b9bcc5fbd9d',4,10000,NULL,100000,NULL,NULL,'2025-05-08 11:30:34',NULL),('315bd8ceb2474d51','9b9bcc5fbd9d',5,10000,NULL,100000,NULL,NULL,'2025-05-08 11:30:34',NULL),('3433bff97c444883','fffa04d48f2a',2,4200,NULL,41500,NULL,NULL,'2025-05-03 13:39:52',NULL),('347bb8f52bde459c','84c332bc7e0b',7,50000,NULL,500000,NULL,NULL,'2025-05-12 09:14:12','2025-05-12 09:14:12'),('4005c0bfa7ce4af0','fffa04d48f2a',7,4700,NULL,44000,NULL,NULL,'2025-05-03 13:39:52',NULL),('41bbf62fb6144213','31694d370df7',1,5000,NULL,50000,NULL,NULL,'2025-05-12 08:43:36',NULL),('42afbcbb15f14af9','9b9bcc5fbd9d',3,10000,NULL,100000,NULL,NULL,'2025-05-08 11:30:34',NULL),('44f3b5ba9c4747c5','31694d370df7',4,5000,NULL,50000,NULL,NULL,'2025-05-12 08:43:36',NULL),('4a859b4ceb344a11','84c332bc7e0b',2,50000,NULL,500000,NULL,NULL,'2025-05-12 09:14:12','2025-05-12 09:14:12'),('4de8e062a1d24eea','b6d3c2655e5c',7,2500,NULL,25000,NULL,NULL,'2025-05-08 11:32:29',NULL),('507b2c56c77d4fbc','31694d370df7',3,5000,NULL,50000,NULL,NULL,'2025-05-12 08:43:36',NULL),('535e50f77ffb4aaa','9b9bcc5fbd9d',2,10000,NULL,100000,NULL,NULL,'2025-05-08 11:30:34',NULL),('55b3a6d14ef14ad0','31694d370df7',9,5000,NULL,50000,NULL,NULL,'2025-05-12 08:43:36',NULL),('55d512bb220447fb','9b9bcc5fbd9d',9,10000,NULL,100000,NULL,NULL,'2025-05-08 11:30:34',NULL),('62b869d591df4d15','9b9bcc5fbd9d',7,10000,NULL,100000,NULL,NULL,'2025-05-08 11:30:34',NULL),('63276b5b0c2e4f7f','b6d3c2655e5c',4,2500,NULL,25000,NULL,NULL,'2025-05-08 11:32:29',NULL),('6583a5afd41c4b4b','31694d370df7',6,5000,NULL,50000,NULL,NULL,'2025-05-12 08:43:36',NULL),('66a2428890bc430a','84c332bc7e0b',1,50000,'8ab099c04852',500000,'2025-05-16','karan metha has ligted a this month chit amount','2025-05-16 07:43:48','2025-05-12 09:14:12'),('7259e2276a474460','84c332bc7e0b',9,50000,NULL,500000,NULL,NULL,'2025-05-12 09:14:12','2025-05-12 09:14:12'),('729fc2c033674d1e','84c332bc7e0b',5,50000,NULL,500000,NULL,NULL,'2025-05-12 09:14:12','2025-05-12 09:14:12'),('7d66668cb3ea47ed','84c332bc7e0b',6,50000,NULL,500000,NULL,NULL,'2025-05-12 09:14:12','2025-05-12 09:14:12'),('7dea890319b445a4','31694d370df7',8,5000,NULL,50000,NULL,NULL,'2025-05-12 08:43:36',NULL),('7e4e79b7ab154d2f','9b9bcc5fbd9d',8,10000,NULL,100000,NULL,NULL,'2025-05-08 11:30:34',NULL),('809a6dc2e6794dc0','b6d3c2655e5c',2,2500,NULL,25000,NULL,NULL,'2025-05-08 11:32:29',NULL),('84389c92b5f44b4f','31694d370df7',7,5000,NULL,50000,NULL,NULL,'2025-05-12 08:43:36',NULL),('87fcb68616754d2f','9b9bcc5fbd9d',6,10000,NULL,100000,NULL,NULL,'2025-05-08 11:30:34',NULL),('8d2f2490ca0b471e','fffa04d48f2a',5,4500,NULL,43000,NULL,NULL,'2025-05-03 13:39:52',NULL),('934836ee7c46468e','31694d370df7',10,5000,NULL,50000,NULL,NULL,'2025-05-12 08:43:36',NULL),('9b3bb58a2ca54b38','fffa04d48f2a',3,4300,NULL,42000,NULL,NULL,'2025-05-03 13:39:52',NULL),('9f704d645fe946bf','84c332bc7e0b',4,50000,NULL,500000,NULL,NULL,'2025-05-12 09:14:12','2025-05-12 09:14:12'),('9faa3fad60e64eb5','fffa04d48f2a',1,4200,'bbc84395d5e2',41000,NULL,NULL,'2025-05-04 08:04:29',NULL),('ba7bdc0bfc06492c','fffa04d48f2a',4,4400,NULL,42500,NULL,NULL,'2025-05-03 13:39:52',NULL),('badaf69ce96547da','b6d3c2655e5c',6,2500,NULL,25000,NULL,NULL,'2025-05-08 11:32:29',NULL),('c2674d3114dd42c7','31694d370df7',5,5000,NULL,50000,NULL,NULL,'2025-05-12 08:43:36',NULL),('c9e7650f033142d3','b6d3c2655e5c',1,2500,'203e4d7dbace',25000,'2025-05-08',NULL,'2025-05-08 14:02:24',NULL),('d15e2cd8f1ba48fb','b6d3c2655e5c',8,2500,NULL,25000,NULL,NULL,'2025-05-08 11:32:29',NULL),('e0fe064cda8f4f2a','9b9bcc5fbd9d',1,10000,NULL,100000,NULL,NULL,'2025-05-08 11:30:34',NULL),('e26f6049bc6343bb','84c332bc7e0b',3,50000,NULL,500000,NULL,NULL,'2025-05-12 09:14:12','2025-05-12 09:14:12'),('e5826d8fad324328','b6d3c2655e5c',10,2500,NULL,25000,NULL,NULL,'2025-05-08 11:32:29',NULL),('eb227db230af4f32','84c332bc7e0b',10,50000,NULL,500000,NULL,NULL,'2025-05-12 09:14:12','2025-05-12 09:14:12'),('eec078a308c742f1','fffa04d48f2a',8,4800,NULL,45000,NULL,NULL,'2025-05-03 13:39:52',NULL),('f108eb5b131d4022','b6d3c2655e5c',3,2500,NULL,25000,NULL,NULL,'2025-05-08 11:32:29',NULL),('f56a21246667446a','fffa04d48f2a',6,4600,NULL,43496,NULL,NULL,'2025-05-03 13:39:52',NULL),('fddf01a23efe468b','b6d3c2655e5c',5,2500,NULL,25000,NULL,NULL,'2025-05-08 11:32:29',NULL),('feb7488b84a84d59','b6d3c2655e5c',9,2500,NULL,25000,NULL,NULL,'2025-05-08 11:32:29',NULL);
/*!40000 ALTER TABLE `monthly_projections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_installments`
--

DROP TABLE IF EXISTS `payment_installments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_installments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_id` varchar(36) NOT NULL,
  `installment_id` varchar(36) NOT NULL,
  `chit_member_id` varchar(36) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chit_member_id` (`chit_member_id`),
  KEY `installment_id` (`installment_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `payment_installments_ibfk_1` FOREIGN KEY (`chit_member_id`) REFERENCES `chit_members` (`chit_member_id`),
  CONSTRAINT `payment_installments_ibfk_2` FOREIGN KEY (`installment_id`) REFERENCES `installments` (`installment_id`),
  CONSTRAINT `payment_installments_ibfk_3` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_installments`
--

LOCK TABLES `payment_installments` WRITE;
/*!40000 ALTER TABLE `payment_installments` DISABLE KEYS */;
INSERT INTO `payment_installments` VALUES (1,'86f07e8e273c4a0aa7','cd9863bd05864c8e','b3aa05b1f664',NULL,NULL),(2,'86f07e8e273c4a0aa7','44003460390d4475','94b87d8a5575',NULL,NULL),(3,'eb8bdbc0cda6488f8c','0c5bac59cb91429d','537fa5ae392d',NULL,NULL),(4,'cfb2c40833214dedba','012b62287e7c4939','d4b0cecf4d29',NULL,NULL),(5,'0a116658a1244de299','685ffe79875f4f30','8ebf0e3a3f6e',NULL,NULL),(6,'ce36b6f167524e4cac','3615b82f4be64b9c','7ee8e77a68b4',NULL,NULL),(7,'ce36b6f167524e4cac','3140015a826e45a8','ddf09043edb6',NULL,NULL),(8,'bd530ec383c54b118f','3140015a826e45a8','ddf09043edb6',NULL,NULL),(9,'189e9a134aa74347a2','41ce0a085e4d44b5','44ffd430d574',NULL,NULL),(10,'bcb0e5d9e2954a288f','3c5ff2c39d9d4d54','8dad4ca0b873',NULL,NULL),(11,'376b7221599a45d391','eb9e8d55f6724cc0','380d85ab0b42',NULL,NULL),(12,'b90d9c60c80b4084be','75791cba9fc9464a','cf2a41cc7c1e',NULL,NULL),(13,'6db6208824254429ac','fed4920d2ad448d5','c04c8268668a',NULL,NULL),(14,'a9735c3a1baa4cf2ae','55151613e04b406c','4e65b2f84984',NULL,NULL);
/*!40000 ALTER TABLE `payment_installments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `payment_id` varchar(36) NOT NULL,
  `payment_amount` float NOT NULL,
  `payment_date` datetime DEFAULT NULL,
  `net_paid_cash` float DEFAULT NULL,
  `net_paid_online` float DEFAULT NULL,
  `payment_method` enum('CASH','PHONEPAY','GPAY','PAYTM','CHEQUE','OTHER') DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `payment_status` enum('SUCCESS','FAILED','PENDING') NOT NULL,
  `note` text,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES ('0a116658a1244de299',10000,'2025-05-08 19:00:43',0,10000,'GPAY','23456','SUCCESS',NULL,NULL,NULL),('189e9a134aa74347a2',4200,'2025-05-12 14:41:00',4200,0,'CASH','','SUCCESS',NULL,NULL,NULL),('376b7221599a45d391',5000,'2025-05-15 13:30:36',5000,0,'CASH','','SUCCESS',NULL,NULL,NULL),('6db6208824254429ac',5000,'2025-05-15 13:31:00',5000,0,'CASH','','SUCCESS',NULL,NULL,NULL),('86f07e8e273c4a0aa7',12500,'2025-05-08 18:43:06',0,12500,'PHONEPAY','12345','SUCCESS',NULL,NULL,NULL),('a9735c3a1baa4cf2ae',5000,'2025-05-15 13:31:11',5000,0,'CASH','','SUCCESS',NULL,NULL,NULL),('b90d9c60c80b4084be',5000,'2025-05-15 13:30:49',5000,0,'CASH','','SUCCESS',NULL,NULL,NULL),('bcb0e5d9e2954a288f',20000,'2025-05-13 15:59:25',20000,0,'CASH','','SUCCESS',NULL,NULL,NULL),('bd530ec383c54b118f',2000,'2025-05-12 14:23:30',2000,0,'CASH','','SUCCESS',NULL,NULL,NULL),('ce36b6f167524e4cac',6000,'2025-05-12 14:23:07',6000,0,'CASH','','SUCCESS',NULL,NULL,NULL),('cfb2c40833214dedba',10000,'2025-05-08 18:58:01',10000,0,'CASH','','SUCCESS',NULL,NULL,NULL),('eb8bdbc0cda6488f8c',10000,'2025-05-08 18:52:50',10000,0,'CASH','','SUCCESS',NULL,NULL,NULL);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` varchar(36) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `aadhaar_number` varchar(12) DEFAULT NULL,
  `pan_number` varchar(10) DEFAULT NULL,
  `address` text,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `role` enum('USER','ADMIN','MANAGER') NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('07a7d3b929e0','Priya Verma','priya.verma@example.com','$2b$12$UCP4bqcxxJ07hwQjJwDmoe45Z60UhnN3/uZKS6M5/oUb5LY3d8uTu','9123456789','234567890123','BCDEA4321K','456, Park Street','Delhi','Delhi','110001','USER','2025-05-03 12:59:39',1,'2025-05-20 09:31:33'),('203e4d7dbace','Rahul Sharma','rahul.sharma@example.com','$2b$12$txBMl0Ig9M1ngaoVdRnqAuGO0dHRXugkxQ5geyzUisYWMrR5xCV3G','9876543210','123456789012','ABCDE1234F','123, MG Road','Mumbai','Maharashtra','400001','USER','2025-05-03 12:58:23',1,'2025-05-20 09:31:33'),('8ab099c04852','Karan Mehta','karan.mehta@example.com','$2b$12$NRGfJEw4hk7hi9e35mQLp.0f0I.Um8Ef5OeRwBYSr0Qdx5KGl6SIC','8899776655','567890123456','EABCD7654R','55, Residency Road','Bangalore','Karnataka','560025','USER','2025-05-03 13:16:32',1,'2025-05-20 09:31:33'),('8e3e52738d50','Amit Patel','amit.patel@example.com','$2b$12$4budJU/727jbl9PNd8uk3OnolJVnzIBoq.kErI2ystorXcrvtPj.a','9988776655','345678901234','CDEAB5432P','78, Ashram Road','Ahmedabad','Gujarat','380009','USER','2025-05-03 12:59:57',1,'2025-05-20 09:31:33'),('bbc84395d5e2','Sneha Reddy','sneha.reddy@example.com','$2b$12$xYKABlu01yWy5Rudg512yOT4AdDshZC0GBHTPFySIDjYnbxwRmfA6','9001122334','456789012345','DEABC6543Q','12, Banjara Hills','Hyderabad','Telangana','500034','USER','2025-05-03 13:00:10',1,'2025-05-20 09:31:33');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-23 12:17:58
